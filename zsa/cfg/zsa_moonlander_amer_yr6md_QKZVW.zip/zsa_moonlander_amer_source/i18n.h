#define KC_PC_COPY LCTL(KC_C)
#define KC_PC_UNDO LCTL(KC_Z)
