#define KC_PC_COPY LCTL(KC_C)
#define KC_PC_UNDO LCTL(KC_Z)
#define KC_PC_PASTE LCTL(KC_V)
#define KC_PC_CUT LCTL(KC_X)
